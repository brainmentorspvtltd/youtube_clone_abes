import 'package:flutter/material.dart';
import 'package:youtube_clone/pages/home.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int index = 0;
  _buildScreens() {
    return [Home(), Text('Subscribe')];
  }

  @override
  Widget build(BuildContext context) {
    // UI Code is Here
    return Scaffold(
      body: _buildScreens()[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (int currentIndex) {
          index = currentIndex;
          setState(() {});
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.subscriptions), label: 'Subscribe')
        ],
      ),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: SizedBox(
          height: 100,
          child: Image.network(
              'https://cdn.iconscout.com/icon/free/png-256/free-youtube-86-226404.png'),
        ),
        actions: const [
          Icon(
            Icons.search,
            color: Colors.red,
          ),
          SizedBox(
            width: 20,
          ),
          Icon(
            Icons.notifications,
            color: Colors.black,
          ),
          SizedBox(
            width: 20,
          ),
          Icon(
            Icons.cast,
            color: Colors.black,
          ),
          SizedBox(
            width: 20,
          )
        ],
      ),
    );
  }
}
